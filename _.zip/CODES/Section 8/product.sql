use mydb

create table product(id int,name varchar(20),description varchar(20),price int)

select * from product